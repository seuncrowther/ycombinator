<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link href="style.css" rel="stylesheet" />
<title>YCombinator Demo</title>
</head>

<body>
	<div class="content">
	<table width="100%" class="htable">
		<tr>
			<td width="18px" valign="center"><a class="logo-border" href=""><img src="img/y18.gif" /></a></td>
			<td valign="center" class="reform">
				<a href=""><b>Hacker News</b></a>
				<a href="">new</a> | <a href="">past</a> | <a href="">comment</a> | <a href="">ask</a> | <a href="">show</a> | <a href="">jobs</a> | <a href="">submit</a>
			</td>
			<td width="50px" valign="center" class="reform">
				<a href="">login</a>
			</td>
		</tr>
	</table>
		
	<table width="100%" class="table-list">
		<tr>
			<td class="rank" width="18px" valign="top"><span class="rank">1.</span></td>
			<td width="5px" valign="top"><div class="upvote"></div></td>
			<td class="title" valign="top">
				<a href="">Slack Is Going Public at a $16B Valuation</a> <span class="source">(npr.org)</span>
				<span class="subtext">425 points by lgats 10 hours ago | hide | 504 comments</span>
			</td>
		</tr>
		<tr>
			<td class="rank" width="18px" valign="top"><span class="rank">1.</span></td>
			<td width="5px" valign="top"><div class="upvote"></div></td>
			<td class="title" valign="top">
				<a href="">Slack Is Going Public at a $16B Valuation</a> <span class="source">(npr.org)</span>
				<span class="subtext">425 points by lgats 10 hours ago | hide | 504 comments</span>
			</td>
		</tr>
	</table>
		
	</div>
</body>
</html>